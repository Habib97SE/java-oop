import habhez0.Uppgift0;

/**
 * Den här klassen innehåller min lösning för uppgift0.
 * ltu-id: habhez-0
 * Namn: Habiballah Hezarehee
 */
public class App
{
   public static void main (String[] args)
   {
      Uppgift0.skrivUt();
   }
}
