package habhez0;

/**
 * Den här klassen innehåller min lösning för uppgift0.
 * ltu-id: habhez-0
 * Namn: Habiballah Hezarehee
 */
public class Uppgift0
{
   /**
    * Den här metoden skriver ut en textsträng.
    */
   public static void skrivUt ()
   {
      System.out.println("Hej Värld!");
   }
}
